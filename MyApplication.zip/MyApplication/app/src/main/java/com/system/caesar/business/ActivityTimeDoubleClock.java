package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageButton;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/18.
 */

public class ActivityTimeDoubleClock extends ActivityBase implements View.OnClickListener {

    private ImageButton timeDoubleClockButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_double_clock);
        setTitle(R.string.double_clock);

        timeDoubleClockButton = (ImageButton) findViewById(R.id.ib_time_double_clock);
        timeDoubleClockButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_time_double_clock:
                // TODO
                break;
        }
    }
}
