package com.system.caesar.business.ui;

import android.content.Context;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.ImageButton;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.WifiController;

/**
 * Created by huison on 2018/7/1.
 */

public class VgItemSettingAirplane extends VgItemSettingCommon {

    private ImageButton toggle;

    public VgItemSettingAirplane(@NonNull Context context) {
        this(context, null);
    }

    public VgItemSettingAirplane(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VgItemSettingAirplane(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        toggle = (ImageButton) container.findViewById(R.id.ib_toggle);
        toggle.setVisibility(VISIBLE);
        enterView.setVisibility(GONE);
    }

    public void refreshAirplaneState() {
        toggle.setSelected(WifiController.instance().isAirplaneModeOn(getContext()));
    }

    public void setToggleOnClickListener(OnClickListener clickListener) {
        toggle.setOnClickListener(clickListener);
    }
}
