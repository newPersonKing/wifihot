package com.system.caesar.business;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.IWifiApListener;
import com.system.caesar.settings.wifi.WifiApClient;
import com.system.caesar.utils.HandlerUtils;
import com.system.caesar.utils.ToastUtils;
import com.system.caesar.settings.wifi.WifiController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huison on 2018/6/3.
 */

public class ActivityWifiAp extends ActivityBase implements View.OnClickListener, IWifiApListener {

    private static final int kRequestSystemSetting = 111;

    private TextView wifiApNameView;
    private ImageButton wifiApToggle;
    private TextView deviceCountView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_ap);

        setTitle(R.string.item_wifi_ap);

        wifiApNameView = (TextView) findViewById(R.id.tx_wifi_ap_name);
        deviceCountView = (TextView) findViewById(R.id.tv_connected_devices);
        deviceCountView.setText(getString(R.string.wifi_ap_connected_count, 0));

        wifiApToggle = (ImageButton) findViewById(R.id.ib_wifi_ap_toggle);
        wifiApToggle.setOnClickListener(this);

        findViewById(R.id.fl_wifi_ap_configuration).setOnClickListener(this);
        findViewById(R.id.fl_connected_devices).setOnClickListener(this);

        if (WifiController.isSettingCanWrite(this)) {
            if (WifiController.instance().isWifiApOpen()) {
                wifiApToggle.setSelected(true);
            } else {
                wifiApToggle.setSelected(false);
            }
        } else {
            WifiController.instance().requestWritePermissionSettings(this, kRequestSystemSetting);
        }
    }

    private Runnable scanWifiApClientsTask = new Runnable() {
        @Override
        public void run() {
            WifiController.instance().scanWifiApClients();
            HandlerUtils.runOnUIThreadDelay(scanWifiApClientsTask, 2000);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        wifiApNameView.setText(WifiController.instance().getWifiApConfiguration().getSSID());
        WifiController.instance().registerWifiApReceiver(this, this);
        HandlerUtils.runOnUIThreadDelay(scanWifiApClientsTask, 2000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        WifiController.instance().unregisterWifiApReceiver(this, this);
        HandlerUtils.removeRunnable(scanWifiApClientsTask);
    }

    @Override
    public void onScanWifiApClients(List<WifiApClient> wifiApClients) {
        if (WifiController.instance().isWifiApOpen()) {
            List<WifiApClient> results = new ArrayList<>();
            for (WifiApClient wifiApClient : wifiApClients) {
                if (wifiApClient.isReachable()) {
                    results.add(wifiApClient);
                }
            }
            deviceCountView.setText(getString(R.string.wifi_ap_connected_count, results.size()));
        } else {
            deviceCountView.setText(getString(R.string.wifi_ap_connected_count, 0));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == kRequestSystemSetting) {
            if (!WifiController.isSettingCanWrite(this)) {
                ToastUtils.showToast("申请权限失败");
                finish();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_wifi_ap_toggle:
                if (WifiController.instance().isWifiApOpen()) {
                    boolean success = WifiController.instance().closeWifiAp();
                    if (success) {
                        wifiApToggle.setSelected(false);
                    }
                } else {
                    boolean success = WifiController.instance().openWifiAp();
                    if (success) {
                        wifiApToggle.setSelected(true);
                    }
                }
                break;
            case R.id.fl_wifi_ap_configuration:
                ActivityBase.open(this, ActivityWifiApDetail.class);
                break;
            case R.id.fl_connected_devices:
                ActivityBase.open(this, ActivityWifiApClients.class);
                break;
            default:
                break;
        }
    }
}
