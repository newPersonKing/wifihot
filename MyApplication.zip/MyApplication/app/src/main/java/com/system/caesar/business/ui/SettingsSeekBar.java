package com.system.caesar.business.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/14.
 */

public class SettingsSeekBar extends View {

    private enum Orientation {
        kVertical(0), kHorizontal(1);

        int value;

        Orientation(int value) {
            this.value = value;
        }

        static Orientation get(int value) {
            if (value == 0) {
                return kVertical;
            } else {
                return kHorizontal;
            }
        }
    }

    private static final int kTotalProgress = 255;

    private static final int kDefaultWidth = 70;
    private static final int kDefaultHeight = 207;

    private Orientation orientation;
    private int bgBitmapResId;
    private int slideBitmapResId;
    private int totalProgress = kTotalProgress;
    private Bitmap bgBitmap;
    private Bitmap sliderBitmap;
    private int bgStartX;
    private int bgStartY;

    private int slideTotalLength;

    private Matrix bgMatrix = new Matrix();
    private Matrix sliderMatrix = new Matrix();

    private int progress;

    public SettingsSeekBar(Context context) {
        this(context, null);
    }

    public SettingsSeekBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SettingsSeekBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.SettingsSeekBar, defStyle, 0);
        orientation = Orientation.get(ta.getInt(R.styleable.SettingsSeekBar_orientation, Orientation.kVertical.value));
        bgBitmapResId = ta.getResourceId(R.styleable.SettingsSeekBar_bgDrawable, R.mipmap.ic_brightness_line);
        slideBitmapResId = ta.getResourceId(R.styleable.SettingsSeekBar_sliderDrawable, R.mipmap.ic_brightness_button);
        totalProgress = ta.getInt(R.styleable.SettingsSeekBar_totalProgress, kTotalProgress);

        ta.recycle();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        bgBitmap = BitmapFactory.decodeResource(getResources(), bgBitmapResId);
        if (orientation == Orientation.kHorizontal) {
            Matrix matrix = new Matrix();
            matrix.setRotate(90);
            Bitmap bitmap = Bitmap.createBitmap(bgBitmap, 0, 0, bgBitmap.getWidth(), bgBitmap.getHeight(), matrix, false);
            if (bitmap != bgBitmap) {
                bgBitmap.recycle();
                bgBitmap = null;
                bgBitmap = bitmap;
            } else {
                bgBitmap = bitmap;
            }
        }

        sliderBitmap = BitmapFactory.decodeResource(getResources(), slideBitmapResId);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        bgBitmap = null;
        sliderBitmap = null;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        if (widthMode != MeasureSpec.EXACTLY) {
            width = kDefaultWidth;
        }
        if (heightMode != MeasureSpec.EXACTLY) {
            height = kDefaultHeight;
        }
        setMeasuredDimension(width, height);

        int bgWidth = bgBitmap.getWidth();
        int bgHeight = bgBitmap.getHeight();
        int sliderWidth = sliderBitmap.getWidth();
        int sliderHeight = sliderBitmap.getHeight();

        if (orientation == Orientation.kHorizontal) {
            float sliderScale = height * 1.0f / sliderHeight;
            sliderMatrix.setScale(sliderScale, sliderScale);

            bgStartX = (int) (sliderWidth * sliderScale / 2);
            bgStartY = (int) ((height - sliderHeight * sliderScale * 0.3f) / 2);

            slideTotalLength = (int) (width - sliderWidth * sliderScale);
        } else {
            float sliderScale = width * 1.0f / sliderWidth;
            sliderMatrix.setScale(sliderScale, sliderScale);

            bgStartX = (int) ((width - sliderWidth * sliderScale * 0.3f) / 2);
            bgStartY = (int) (sliderHeight * sliderScale / 2);

            slideTotalLength = (int) (height - sliderHeight * sliderScale);
        }
        float bgScaleX = (width - bgStartX * 2) * 1.0f / bgWidth;
        float bgScaleY = (height - bgStartY * 2) * 1.0f / bgHeight;
        bgMatrix.setScale(bgScaleX, bgScaleY);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(bgStartX, bgStartY);
        canvas.drawBitmap(bgBitmap, bgMatrix, null);
        canvas.translate(-bgStartX, -bgStartY);

        if (orientation == Orientation.kHorizontal) {
            int slideDx = (int) (slideTotalLength * progress * 1.0f / totalProgress);
            canvas.translate(slideDx, 0);
        } else {
            int slideDy = (int) (slideTotalLength * (1 - progress * 1.0f / totalProgress));
            canvas.translate(0, slideDy);
        }
        canvas.drawBitmap(sliderBitmap, sliderMatrix, null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (orientation == Orientation.kHorizontal) {
                    float x = event.getX();
                    if (x < bgStartX) {
                        x = bgStartX;
                    }
                    if (x > bgStartX + slideTotalLength) {
                        x = bgStartX + slideTotalLength;
                    }
                    progress = (int) (totalProgress * ((x - bgStartX) * 1.0f / slideTotalLength));
                } else {
                    float y = event.getY();
                    if (y < bgStartY) {
                        y = bgStartY;
                    }
                    if (y > bgStartY + slideTotalLength) {
                        y = bgStartY + slideTotalLength;
                    }
                    progress = (int) (totalProgress * (1 - ((y - bgStartY) * 1.0f / slideTotalLength)));
                }
                invalidate();
                if (listener != null) {
                    listener.onProgressChanged(this, progress);
                }
                break;
        }
        return true;
    }

    public void setMaxProgress(int maxProgress) {
        this.totalProgress = maxProgress;
        invalidate();
    }

    public void setProgress(int progress) {
        this.progress = progress;
        invalidate();
    }

    private OnSeekBarChangedListener listener;

    public void setOnSeekBarChangedListener(OnSeekBarChangedListener listener) {
        this.listener = listener;
    }

    public interface OnSeekBarChangedListener {
        void onProgressChanged(View view, int progress);
    }
}
