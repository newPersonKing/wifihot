package com.system.caesar.business;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.system.caesar.settings.bluetooth.BluetoothController;
import com.system.caesar.settings.wifi.WifiController;

/**
 * Created by huison on 2018/5/28.
 */

public class CaesarApplication extends Application {

    private static CaesarApplication context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        WifiController.instance().init(this);
        BluetoothController.instance().init(this);
    }

    public static Context context() {
        return context;
    }

    public static SharedPreferences getSharedPreferences() {
        return context().getSharedPreferences("caesar_app", MODE_APPEND);
    }
}
