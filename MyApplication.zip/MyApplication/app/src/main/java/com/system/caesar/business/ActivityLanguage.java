package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.SettingsController;

import java.util.Locale;

/**
 * Created by huison on 2018/6/14.
 */

public class ActivityLanguage extends ActivityBase {


    LanguageAdapter languageAdapter;

    @Override
    protected boolean hasNavigationBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        TextView titleView = (TextView) findViewById(R.id.tv_title);
        titleView.setText(getString(R.string.item_language));
        findViewById(R.id.ib_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rv_language);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        languageAdapter = new LanguageAdapter();
        recyclerView.setAdapter(languageAdapter);

        Locale[] locales = SettingsController.getSystemLanguages();
        languageAdapter.notifyData(locales);
    }

    private class LanguageAdapter extends RecyclerView.Adapter<LanguageHolder> {

        Locale[] locales;

        void notifyData(Locale[] locales) {
            this.locales = locales;
            notifyDataSetChanged();
        }

        @Override
        public LanguageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_language, parent, false);
            return new LanguageHolder(view);
        }

        @Override
        public void onBindViewHolder(LanguageHolder holder, int position) {
            holder.bindData(locales[position], position);
        }

        @Override
        public int getItemCount() {
            return locales == null ? 0 : locales.length;
        }
    }

    private class LanguageHolder extends RecyclerView.ViewHolder {

        TextView languageView;

        LanguageHolder(View itemView) {
            super(itemView);
            languageView = (TextView) itemView;
        }

        void bindData(Locale locale, int position) {
            languageView.setText(locale.getDisplayName());
            languageView.setSelected(position == 0);
        }
    }
}
