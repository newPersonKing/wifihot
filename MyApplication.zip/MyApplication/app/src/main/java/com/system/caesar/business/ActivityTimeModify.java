package com.system.caesar.business;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import com.system.caesar.R;
import com.system.caesar.business.ui.TimePicker;
import com.system.caesar.settings.SettingsController;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityTimeModify extends ActivityBase implements TimePicker.OnTimePickerListener {

    public static void open(Context context, int timeType) {
        Intent intent = new Intent(context, ActivityTimeModify.class);
        intent.putExtra("time_type", timeType);
        context.startActivity(intent);
    }

    @Override
    protected boolean hasBackView() {
        return false;
    }

    private long times = System.currentTimeMillis();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int timeType = getIntent().getIntExtra("time_type", TimePicker.kTimeTypeDate);

        setContentView(R.layout.activity_time_modify);
        if (timeType == TimePicker.kTimeTypeDate) {
            setTitle(R.string.date);
        } else {
            setTitle(R.string.time);
        }

        TimePicker timePicker = (TimePicker) findViewById(R.id.time_picker);
        timePicker.setTimeType(timeType);

        findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button saveButton = (Button) findViewById(R.id.btn_sure);
        saveButton.setText(R.string.save);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SettingsController.setSystemTimes(ActivityTimeModify.this, times);
            }
        });
    }

    @Override
    public void onTimesChanged(long times) {
        this.times = times;
    }
}
