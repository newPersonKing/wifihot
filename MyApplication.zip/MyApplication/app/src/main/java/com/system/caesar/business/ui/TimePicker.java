package com.system.caesar.business.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.system.caesar.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by huison on 2018/6/17.
 */

public class TimePicker extends LinearLayout implements View.OnClickListener {

    public static final int kTimeTypeDate = 0;
    public static final int kTimeTypeTime = 1;

    public interface OnTimePickerListener {
        void onTimesChanged(long times);
    }

    private int timeType;

    private LinearLayout timePickerLayout1;
    private TextView timeText1;
    private LinearLayout timePickerLayout2;
    private TextView timeText2;
    private LinearLayout timePickerLayout3;
    private TextView timeText3;

    private ViewGroup.LayoutParams params1;
    private ViewGroup.LayoutParams params2;
    private ViewGroup.LayoutParams params3;

    private OnTimePickerListener listener;

    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;

    public TimePicker(Context context) {
        this(context, null);
    }

    public TimePicker(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TimePicker(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.layout_time_picker, this);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TimePicker, defStyleAttr, 0);
        timeType = ta.getInt(R.styleable.TimePicker_timeType, kTimeTypeDate);
        ta.recycle();

        initView();
        initData();
    }

    private void initView() {
        timePickerLayout1 = (LinearLayout) findViewById(R.id.ll_time_picker_1);
        timePickerLayout2 = (LinearLayout) findViewById(R.id.ll_time_picker_2);
        timePickerLayout3 = (LinearLayout) findViewById(R.id.ll_time_picker_3);
        timeText1 = (TextView) findViewById(R.id.tv_time_picker_1);
        timeText2 = (TextView) findViewById(R.id.tv_time_picker_2);
        timeText3 = (TextView) findViewById(R.id.tv_time_picker_3);
        findViewById(R.id.ib_time_picker_up_1).setOnClickListener(this);
        findViewById(R.id.ib_time_picker_up_2).setOnClickListener(this);
        findViewById(R.id.ib_time_picker_up_3).setOnClickListener(this);
        findViewById(R.id.ib_time_picker_down_1).setOnClickListener(this);
        findViewById(R.id.ib_time_picker_down_2).setOnClickListener(this);
        findViewById(R.id.ib_time_picker_down_3).setOnClickListener(this);

        params1 = timePickerLayout1.getLayoutParams();
        params2 = timePickerLayout2.getLayoutParams();
        params3 = timePickerLayout3.getLayoutParams();
    }

    private void initData() {
        long time = System.currentTimeMillis();
        if (timeType == kTimeTypeDate) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String timeStr = dateFormat.format(new Date(time));
            String[] str = timeStr.split("-");
            year = Integer.valueOf(str[0]);
            month = Integer.valueOf(str[1]);
            day = Integer.valueOf(str[2]);

            timeText1.setText(str[0]);
            timeText2.setText(str[1]);
            timeText3.setText(str[2]);
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("HH-mm");
            String timeStr = dateFormat.format(new Date(time));
            String[] str = timeStr.split("-");
            hour = Integer.valueOf(str[0]);
            minute = Integer.valueOf(str[1]);

            timeText1.setText(str[0]);
            timeText2.setText(str[1]);
        }
    }

    public void setTimeType(int timeType) {
        this.timeType = timeType;
        initData();
    }

    public void setOnTimePickerListener(OnTimePickerListener listener) {
        this.listener = listener;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int itemWidth = getMeasuredWidth() / 3;

        params1.width = itemWidth;
        timePickerLayout1.setLayoutParams(params1);

        params2.width = itemWidth;
        timePickerLayout2.setLayoutParams(params2);

        params3.width = itemWidth;
        timePickerLayout3.setLayoutParams(params3);

        if (timeType == kTimeTypeTime) {
            timePickerLayout3.setVisibility(GONE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            // up
            case R.id.ib_time_picker_up_1:
                if (timeType == kTimeTypeDate) {
                    year++;
                    timeText1.setText(String.format("%02d", year));
                    checkMaxDayByYearMonth();
                } else {
                    if (hour < 23) {
                        hour++;
                        timeText1.setText(String.format("%02d", hour));
                    }
                }
                break;
            case R.id.ib_time_picker_up_2:
                if (timeType == kTimeTypeDate) {
                    if (month < 12) {
                        month++;
                        timeText2.setText(String.format("%02d", month));
                        checkMaxDayByYearMonth();
                    }
                } else {
                    if (minute < 58) {
                        minute++;
                        timeText2.setText(String.format("%02d", minute));
                    }
                }
                break;
            case R.id.ib_time_picker_up_3:
                if (timeType == kTimeTypeDate) {
                    if (day < getMaxDayByYearMonth(year, month)) {
                        day++;
                        timeText3.setText(String.format("%02d", day));
                    }
                }
                break;
            // down
            case R.id.ib_time_picker_down_1:
                if (timeType == kTimeTypeDate) {
                    if (year > 1900) {
                        year--;
                        timeText1.setText(String.format("%02d", year));
                        checkMaxDayByYearMonth();
                    }
                } else {
                    if (hour > 0) {
                        hour--;
                        timeText1.setText(String.format("%02d", hour));
                    }
                }
                break;
            case R.id.ib_time_picker_down_2:
                if (timeType == kTimeTypeDate) {
                    if (month > 1) {
                        month--;
                        timeText2.setText(String.format("%02d", month));
                        checkMaxDayByYearMonth();
                    }
                } else {
                    if (minute > 0) {
                        minute--;
                        timeText2.setText(String.format("%02d", minute));
                    }
                }
                break;
            case R.id.ib_time_picker_down_3:
                if (timeType == kTimeTypeDate) {
                    if (day > 0) {
                        day--;
                        timeText3.setText(String.format("%02d", day));
                    }
                }
                break;
        }
        if (listener != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year - 1);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            listener.onTimesChanged(calendar.getTimeInMillis());
        }
    }

    private void checkMaxDayByYearMonth() {
        int maxDay = getMaxDayByYearMonth(year, month);
        if (day > maxDay) {
            day = maxDay;
            timeText3.setText(String.valueOf(day));
        }
    }

    private static int getMaxDayByYearMonth(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year - 1);
        calendar.set(Calendar.MONTH, month);
        return calendar.getActualMaximum(Calendar.DATE);
    }
}
