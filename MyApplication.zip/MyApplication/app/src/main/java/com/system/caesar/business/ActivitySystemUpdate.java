package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/18.
 */

public class ActivitySystemUpdate extends ActivityBase {

    @Override
    protected boolean hasNavigationBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system_update);

        TextView titleView = (TextView) findViewById(R.id.tv_title);
        titleView.setText(getString(R.string.item_system_update));
        findViewById(R.id.ib_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button sureButton = (Button) findViewById(R.id.btn_sure);
        sureButton.setText("检测");
        sureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO
            }
        });
    }
}
