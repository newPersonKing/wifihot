package com.system.caesar.utils;

/**
 * Created by huison on 2017/12/21.
 */

public class TimeReduceUtils {

    private int seconds;
    private boolean inCountDown;
    private OnCountDownListener listener;

    public TimeReduceUtils(int seconds) {
        this.seconds = seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public void setListener(OnCountDownListener listener) {
        this.listener = listener;
    }

    public void start() {
        if (seconds > 0 && !inCountDown) {
            inCountDown = true;
            HandlerUtils.runOnUIThreadDelay(runnable, 1000);
        }
    }

    public void pause() {
        inCountDown = false;
        HandlerUtils.removeRunnable(runnable);
    }

    public void stop() {
        inCountDown = false;
        HandlerUtils.removeRunnable(runnable);
        listener = null;
        seconds = 0;
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (seconds <= 0) {
                HandlerUtils.removeRunnable(this);
            } else {
                seconds--;
                HandlerUtils.runOnUIThreadDelay(runnable, 1000);
            }
            if (listener != null) {
                listener.onCountDown(seconds);
            }
        }
    };

    public interface OnCountDownListener {
        void onCountDown(int seconds);
    }
}
