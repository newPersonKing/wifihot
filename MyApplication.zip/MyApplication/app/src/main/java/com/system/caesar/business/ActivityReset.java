package com.system.caesar.business;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/18.
 */

public class ActivityReset extends ActivityBase implements View.OnClickListener {

    @Override
    protected boolean hasNavigationBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset);

        TextView titleView = (TextView) findViewById(R.id.tv_title);
        titleView.setText(getString(R.string.item_reset));
        findViewById(R.id.ib_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button sureButton = (Button) findViewById(R.id.btn_sure);
        sureButton.setText("恢复");
        sureButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName componentName = new ComponentName(this, ResetBroadcastReceiver.class);
            boolean isAdminActive = devicePolicyManager.isAdminActive(componentName);
            if (isAdminActive) {
                devicePolicyManager.wipeData(0);
            } else {
                Intent intent = new Intent();
                intent.setAction(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName);
                startActivity(intent);
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
}
