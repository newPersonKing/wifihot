package com.system.caesar.business;

import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.telephony.SignalStrength;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.SettingsController;

/**
 * Created by huison on 2018/6/5.
 */

public class ActivitySettings extends ActivityBase implements View.OnClickListener {

    private Button brightnessAutoButton;
    private Button brightnessHandButton;
    private SeekBar brightnessSeekBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        brightnessSeekBar = (SeekBar) findViewById(R.id.sb_screen_brightness);
        int brightness = SettingsController.getScreenBrightness(this);
        brightnessSeekBar.setProgress((int) (brightness * 1.0f / 255));
        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int brightness = (int) (255 * 1.0f * progress / 100);
                SettingsController.setScreenBrightness(ActivitySettings.this, brightness);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        brightnessAutoButton = (Button) findViewById(R.id.btn_screen_brightness_mode_auto);
        brightnessAutoButton.setOnClickListener(this);
        brightnessHandButton = (Button) findViewById(R.id.btn_screen_brightness_mode_hand);
        brightnessHandButton.setOnClickListener(this);

        int brightnessMode = SettingsController.getScreenBrightnessMode(this);
        if (brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
            brightnessAutoButton.setSelected(true);
            brightnessHandButton.setSelected(false);
            brightnessSeekBar.setEnabled(false);
        } else {
            brightnessAutoButton.setSelected(false);
            brightnessHandButton.setSelected(true);
            brightnessSeekBar.setEnabled(true);
        }

        SeekBar ringVolumeSeekBar = (SeekBar) findViewById(R.id.sb_ring_volume);
        int ringVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_RING);
        final int maxRingVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_RING);
        ringVolumeSeekBar.setProgress((int) (ringVolume * 100.0f / maxRingVolume));
        ringVolumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int ringVolume = (int) (maxRingVolume * 1.0f * progress / 100);
                SettingsController.setStreamVolume(ActivitySettings.this, AudioManager.STREAM_RING, ringVolume, true);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar mediaVolumeSeekBar = (SeekBar) findViewById(R.id.sb_media_volume);
        int mediaVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_MUSIC);
        final int maxMediaVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_MUSIC);
        mediaVolumeSeekBar.setProgress((int) (mediaVolume * 100.0f / maxMediaVolume));
        mediaVolumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int mediaVolume = (int) (maxMediaVolume * 1.0f * progress / 100);
                SettingsController.setStreamVolume(ActivitySettings.this, AudioManager.STREAM_MUSIC, mediaVolume, true);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar phoneVolumeSeekBar = (SeekBar) findViewById(R.id.sb_phone_volume);
        int phoneVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_VOICE_CALL);
        final int maxPhoneVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_VOICE_CALL);
        phoneVolumeSeekBar.setProgress((int) (phoneVolume * 100.0f / maxPhoneVolume));
        phoneVolumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int phoneVolume = (int) (maxPhoneVolume * 1.0f * progress / 100);
                SettingsController.setStreamVolume(ActivitySettings.this, AudioManager.STREAM_VOICE_CALL, phoneVolume, false);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar alarmVolumeSeekBar = (SeekBar) findViewById(R.id.sb_alarm_volume);
        int alarmVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_ALARM);
        final int maxAlarmVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_ALARM);
        alarmVolumeSeekBar.setProgress((int) (alarmVolume * 100.0f / maxAlarmVolume));
        alarmVolumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int alarmVolume = (int) (maxAlarmVolume * 1.0f * progress / 100);
                SettingsController.setStreamVolume(ActivitySettings.this, AudioManager.STREAM_ALARM, alarmVolume, false);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        TextView operatorTextView = (TextView) findViewById(R.id.status_tv_operator);
        operatorTextView.setText("手机运行商：" + SettingsController.getOperator(this));

        final TextView batteryTextView = (TextView) findViewById(R.id.tv_battery);
        SettingsController.setOnBatteryChangedListener(this, new SettingsController.OnBatteryChangedListener() {
            @Override
            public void onBatteryChanged(int capacity) {

                batteryTextView.setText("手机电量：" + capacity);
            }
        });

        final TextView signalStrengthTextView = (TextView) findViewById(R.id.tv_signal_strength);
        SettingsController.querySignalStrength(this, new SettingsController.OnSignalStrengthListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onReadSignalStrength(SignalStrength signalStrength) {
                signalStrengthTextView.setText("信号强度：" + signalStrength.getLevel());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SettingsController.release();
    }

    @Override
    public void onClick(View v) {
        boolean success;
        switch (v.getId()) {
            case R.id.btn_screen_brightness_mode_auto:
                success = SettingsController.setScreenBrightnessMode(this, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
                if (success) {
                    brightnessAutoButton.setSelected(true);
                    brightnessHandButton.setSelected(false);
                    brightnessSeekBar.setEnabled(false);
                }
                break;
            case R.id.btn_screen_brightness_mode_hand:
                success = SettingsController.setScreenBrightnessMode(this, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                if (success) {
                    brightnessAutoButton.setSelected(false);
                    brightnessHandButton.setSelected(true);
                    brightnessSeekBar.setEnabled(true);
                }
                break;
        }
    }
}
