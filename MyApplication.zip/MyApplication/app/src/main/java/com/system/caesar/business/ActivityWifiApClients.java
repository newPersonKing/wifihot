package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.IWifiApListener;
import com.system.caesar.settings.wifi.WifiApClient;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.utils.HandlerUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityWifiApClients extends ActivityBase implements IWifiApListener {

    private TextView deviceCountView;
    private WifiApDeviceAdapter adapter;

    private List<WifiApClient> results;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_ap_clients);

        setTitle(R.string.wifi_ap_connected_devices);

        deviceCountView = (TextView) findViewById(R.id.tv_wifi_ap_devices_count);
        deviceCountView.setText(getString(R.string.wifi_ap_connected_count, 0));

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rv_wifi_ap_devices);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WifiApDeviceAdapter();
        recyclerView.setAdapter(adapter);
    }

    private Runnable scanWifiApClientsTask = new Runnable() {
        @Override
        public void run() {
            WifiController.instance().scanWifiApClients();
            HandlerUtils.runOnUIThreadDelay(scanWifiApClientsTask, 2000);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        WifiController.instance().registerWifiApReceiver(this, this);
        HandlerUtils.runOnUIThreadDelay(scanWifiApClientsTask, 2000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        WifiController.instance().unregisterWifiApReceiver(this, this);
        HandlerUtils.removeRunnable(scanWifiApClientsTask);
    }

    @Override
    public void onScanWifiApClients(List<WifiApClient> wifiApClients) {
        results = new ArrayList<>();
        if (WifiController.instance().isWifiApOpen()) {
            for (WifiApClient wifiApClient : wifiApClients) {
                if (wifiApClient.isReachable()) {
                    results.add(wifiApClient);
                }
            }
        }
        adapter.notifyData(results);
        deviceCountView.setText(getString(R.string.wifi_ap_connected_count, results.size()));
    }

    private class WifiApDeviceAdapter extends RecyclerView.Adapter<WifiApDeviceHolder> {

        List<WifiApClient> wifiApDevices;

        WifiApDeviceAdapter() {

        }

        void notifyData(List<WifiApClient> wifiApDevices) {
            this.wifiApDevices = wifiApDevices;
            notifyDataSetChanged();
        }

        @Override
        public WifiApDeviceHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wifi_ap_device, parent, false);
            return new WifiApDeviceHolder(view);
        }

        @Override
        public void onBindViewHolder(WifiApDeviceHolder holder, int position) {
            holder.bindData(wifiApDevices.get(position), position);
        }

        @Override
        public int getItemCount() {
            return wifiApDevices == null ? 0 : wifiApDevices.size();
        }
    }

    private class WifiApDeviceHolder extends RecyclerView.ViewHolder {

        TextView deviceNameView;
        LinearLayout editNameLayout;
        EditText editNameView;
        TextView saveNameButton;
        TextView cancelNameButton;
        TextView deviceIpView;
        TextView deviceMacView;

        WifiApClient wifiApClient;
        int position;

        public WifiApDeviceHolder(View itemView) {
            super(itemView);
            deviceNameView = (TextView) itemView.findViewById(R.id.tv_device_name);
            editNameLayout = (LinearLayout) itemView.findViewById(R.id.ll_device_name_edit);
            editNameView = (EditText) itemView.findViewById(R.id.et_device_name);
            saveNameButton = (TextView) itemView.findViewById(R.id.tv_save);
            cancelNameButton = (TextView) itemView.findViewById(R.id.tv_cancel);
            deviceIpView = (TextView) itemView.findViewById(R.id.tv_device_ip);
            deviceMacView = (TextView) itemView.findViewById(R.id.tv_device_mac);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (deviceNameView.getVisibility() == View.VISIBLE) {
                        deviceNameView.setVisibility(View.GONE);
                        editNameLayout.setVisibility(View.VISIBLE);
                        String name = WifiController.instance().getWifiApClientName(wifiApClient.getClientIp());
                        if (!TextUtils.isEmpty(name)) {
                            editNameView.setText(name);
                            editNameView.setSelection(name.length());
                        }
                    }
                    return false;
                }
            });
            saveNameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deviceNameView.setVisibility(View.VISIBLE);
                    editNameLayout.setVisibility(View.GONE);
                    String name = editNameView.getText().toString();
                    WifiController.instance().saveWifiApClientName(wifiApClient.getClientIp(), name);
                    results.get(position).setClientName(name);
                    adapter.notifyDataSetChanged();
                }
            });
            cancelNameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deviceNameView.setVisibility(View.VISIBLE);
                    editNameLayout.setVisibility(View.GONE);
                }
            });
        }

        void bindData(WifiApClient wifiApDevice, int position) {
            this.wifiApClient = wifiApDevice;
            this.position = position;
            deviceNameView.setText(wifiApDevice.getClientName());
            deviceIpView.setText(getString(R.string.wifi_ap_device_ip_format, wifiApDevice.getClientIp()));
            deviceMacView.setText(getString(R.string.wifi_ap_device_mac_format, wifiApDevice.getClientMac()));
        }
    }
}
