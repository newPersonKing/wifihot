package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityBluetoothHelper extends ActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_helper);

        setTitle("帮助");
    }
}
