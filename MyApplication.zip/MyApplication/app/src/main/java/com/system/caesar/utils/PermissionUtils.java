package com.system.caesar.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.content.ContextCompat;

public class PermissionUtils {

    public static boolean checkPermission(Context context, String permission) {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean checkAndRequestLocationPermission(Activity activity, int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !checkPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION)) {
            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, requestCode);
            return false;
        }
        return true;
    }

    public static boolean checkAndRequestPhoneStatePermission(Activity activity, int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int hasPermission = activity.checkSelfPermission(Manifest.permission.READ_PHONE_STATE);
            if (hasPermission != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, requestCode);
                return false;
            }
        }
        return true;
    }

    public static boolean checkAndRequestPermission(Activity activity, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int hasPermission = activity.checkSelfPermission(Manifest.permission.READ_PHONE_STATE);
            if (hasPermission != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(permissions, 0);
                return false;
            }
        }
        return true;
    }
}
