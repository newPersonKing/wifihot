package com.system.caesar.business;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.utils.ToastUtils;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.settings.wifi.WifiDetail;

/**
 * Created by huison on 2018/6/16.
 */

public class ActivityWifiDetail extends ActivityBase implements View.OnClickListener, WifiController.WifiConnectCallback {

    public static void openForResult(ActivityBase activity, int requestCode, WifiDetail wifiDetail) {
        if (wifiDetail == null) {
            return;
        }
        Intent intent = new Intent();
        intent.setClass(activity, ActivityWifiDetail.class);
        intent.putExtra("wifi_detail", wifiDetail);
        activity.startActivityForResult(intent, requestCode);
    }

    private FrameLayout stateLayout;
    private TextView strengthTextView;
    private TextView capabilitiesTextView;
    private LinearLayout passwordLayout;
    private EditText passwordEditText;
    private Button cancelButton;
    private Button sureButton;

    private WifiDetail wifiDetail;
    private WifiConfiguration historyConfiguration;

    @Override
    protected boolean hasBackView() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_detail);

        wifiDetail = (WifiDetail) getIntent().getSerializableExtra("wifi_detail");

        stateLayout = (FrameLayout) findViewById(R.id.fl_wifi_state);
        strengthTextView = (TextView) findViewById(R.id.tv_wifi_strength);
        capabilitiesTextView = (TextView) findViewById(R.id.tv_wifi_capabilities);
        passwordLayout = (LinearLayout) findViewById(R.id.fl_wifi_password);
        passwordEditText = (EditText) findViewById(R.id.et_wifi_password);
        cancelButton = (Button) findViewById(R.id.btn_cancel);
        sureButton = (Button) findViewById(R.id.btn_sure);
        cancelButton.setOnClickListener(this);
        sureButton.setOnClickListener(this);

        setTitle(wifiDetail.getWifiName());
        if (wifiDetail.getState() == WifiDetail.kStateConnected) {
            stateLayout.setVisibility(View.VISIBLE);
            passwordLayout.setVisibility(View.GONE);
            sureButton.setText("断开");
        } else {
            stateLayout.setVisibility(View.GONE);
            passwordLayout.setVisibility(View.VISIBLE);
            sureButton.setText("连接");
        }
        if (wifiDetail.getStrength() == WifiDetail.kStrengthFull) {
            strengthTextView.setText("强");
        } else if (wifiDetail.getStrength() == WifiDetail.kStrengthThreePiece) {
            strengthTextView.setText("较强");
        } else if (wifiDetail.getStrength() == WifiDetail.kStrengthTwoPiece) {
            strengthTextView.setText("中");
        } else {
            strengthTextView.setText("弱");
        }
        if (wifiDetail.isEncrypted()) {
            capabilitiesTextView.setText(wifiDetail.getCapabilities());
        } else {
            capabilitiesTextView.setText("未加密");
        }

        historyConfiguration = WifiController.instance().isHistoryConnection(wifiDetail);
        if (historyConfiguration != null) {
            passwordLayout.setVisibility(View.GONE);
            if (wifiDetail.getState() == WifiDetail.kStateDisconnected) {
                cancelButton.setText("忘记网络");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WifiController.instance().registerWifiReceiver(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        WifiController.instance().unregisterWifiReceiver(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_cancel) {
            if (wifiDetail.getState() != WifiDetail.kStateConnected && historyConfiguration != null) {
                WifiController.instance().forgetWifi(historyConfiguration.networkId);
            }
            finish();
        } else if (v.getId() == R.id.btn_sure) {
            if (wifiDetail.getState() == WifiDetail.kStateConnected) {
                boolean success = WifiController.instance().disconnectWifi();
                if (success) {
                    setResult(RESULT_OK);
                    finish();
                }
            } else {
                if (historyConfiguration != null) {
                    WifiController.instance().connectToWifi(historyConfiguration, this);
                } else {
                    WifiConfiguration configuration =
                            WifiController.instance().genWifiConfiguration(wifiDetail, passwordEditText.getText().toString());
                    WifiController.instance().connectToWifi(configuration, this);
                }
            }
            showLoading();
        }
    }

    @Override
    public void onWifiConnect(boolean success, String error) {
        dismissLoading();
        if (success) {
            setResult(RESULT_OK);
            finish();
        } else {
            showAlertDialog(error, "我知道了", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            if (error.contains("密码错误")) {
                WifiController.instance().forgetWifi();
                historyConfiguration = null;
                passwordLayout.setVisibility(View.VISIBLE);
            }
        }
    }
}
