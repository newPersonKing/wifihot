package com.system.caesar.business;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.bluetooth.BluetoothController;
import com.system.caesar.settings.bluetooth.BluetoothDetail;
import com.system.caesar.settings.bluetooth.IBluetoothListener;
import com.system.caesar.utils.TimeReduceUtils;
import com.system.caesar.utils.ToastUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by huison on 2018/6/3.
 */

public class ActivityBluetooth extends ActivityBase implements View.OnClickListener, IBluetoothListener, TimeReduceUtils.OnCountDownListener {

    private static final int kRequestCodeOpenForDiscover = 100;
    private static final int kRequestCodeBluetoothDetail = 101;
    private static final int kRequestCodeBluetoothOwn = 102;
    private static final int kDiscoverDuration = 120;

    private static final String kLastDiscoverTimes = "last_bluetooth_discover_times";

    private SharedPreferences sharedPref;

    private ImageButton bluetoothToggle;
    private ImageButton beDiscoverToggle;
    private TextView beDiscoverDurationView;
    private TextView ownBluetoothNameView;
    private ProgressBar loadingBar;
    private ImageView loadingButton;
    private BluetoothResultsAdapter adapter;
    private List<BluetoothDetail> bluetoothList = new ArrayList<>();
    private Map<String, BluetoothDetail> bluetoothHashMap = new HashMap<>();

    private boolean canDiscover;
    private TimeReduceUtils timeReduceUtils;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        setTitle(R.string.item_bluetooth);

        sharedPref = CaesarApplication.getSharedPreferences();

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rv_bluetooth_results);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BluetoothResultsAdapter();
        recyclerView.setAdapter(adapter);

        bluetoothToggle = (ImageButton) findViewById(R.id.ib_bluetooth_toggle);
        bluetoothToggle.setOnClickListener(this);

        beDiscoverToggle = (ImageButton) findViewById(R.id.ib_open_for_scan_toggle);
        beDiscoverToggle.setOnClickListener(this);

        beDiscoverDurationView = (TextView) findViewById(R.id.tv_discover_duration);

        loadingBar = (ProgressBar) findViewById(R.id.pb_loading);
        loadingButton = (ImageView) findViewById(R.id.iv_loading);
        loadingButton.setOnClickListener(this);

        findViewById(R.id.fl_own_bluetooth).setOnClickListener(this);
        ownBluetoothNameView = (TextView) findViewById(R.id.tv_own_bluetooth_name);
        ownBluetoothNameView.setText(BluetoothController.instance().getOwnBluetoothName());

        timeReduceUtils = new TimeReduceUtils(kDiscoverDuration);
        timeReduceUtils.setListener(this);

        boolean isBluetoothOpen = BluetoothController.instance().isBluetoothOpen();
        bluetoothToggle.setSelected(isBluetoothOpen);
        if (isBluetoothOpen) {
            BluetoothController.instance().startScan(this);
        }
        long lastDiscoverTimes = sharedPref.getLong(kLastDiscoverTimes, 0);
        int timeDiff = (int) ((System.currentTimeMillis() - lastDiscoverTimes) / 1000);
        canDiscover = timeDiff < kDiscoverDuration;
        beDiscoverToggle.setSelected(canDiscover);
        if (canDiscover) {
            int leftDuration = kDiscoverDuration - timeDiff;
            timeReduceUtils.setSeconds(leftDuration);
            timeReduceUtils.start();
            String durationStr = String.format("%02d", leftDuration / 60) + ":" + String.format("%02d", leftDuration % 60);
            beDiscoverDurationView.setText(getString(R.string.allow_be_discover, String.valueOf(durationStr)));
        } else {
            beDiscoverDurationView.setText(getString(R.string.disallow_be_discover));
        }

        addBluetooth(BluetoothController.instance().getBondedDevices());
        adapter.notifyData(bluetoothList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        BluetoothController.instance().registerScanner(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        BluetoothController.instance().unregisterScanner(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BluetoothController.instance().stopScan();
        timeReduceUtils.stop();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_bluetooth_toggle:
                boolean isBluetoothOpen = BluetoothController.instance().isBluetoothOpen();
                if (isBluetoothOpen) {
                    BluetoothController.instance().stopScan();
                    boolean success = BluetoothController.instance().closeBluetooth();
                    if (success) {
                        bluetoothToggle.setSelected(false);
                    }
                } else {
                    boolean success = BluetoothController.instance().openBluetooth();
                    if (success) {
                        bluetoothToggle.setSelected(true);
                    }
                }
                break;
            case R.id.ib_open_for_scan_toggle:
                if (canDiscover) {
                    BluetoothController.instance().disableDiscover(this);
                    disableDiscover();
                } else {
                    BluetoothController.instance().enableDiscover(this, kDiscoverDuration, kRequestCodeOpenForDiscover);
                }
                break;
            case R.id.fl_own_bluetooth:
                ActivityBluetoothDetail.openForResult(this, kRequestCodeBluetoothOwn);
                break;
            case R.id.iv_loading:
                if (!BluetoothController.instance().isScanning()) {
                    BluetoothController.instance().startScan(this);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == kRequestCodeOpenForDiscover) {
            if (resultCode == kDiscoverDuration) {
                enableDiscover();
            } else if (resultCode == RESULT_CANCELED) {
                disableDiscover();
            }
        } else if (requestCode == kRequestCodeBluetoothDetail) {
            // TODO
        } else if (requestCode == kRequestCodeBluetoothOwn) {
            if (resultCode == RESULT_OK) {
                ownBluetoothNameView.setText(BluetoothController.instance().getOwnBluetoothName());
            }
        }
    }

    @Override
    public void onCountDown(int seconds) {
        String durationStr = String.format("%02d", seconds / 60) + ":" + String.format("%02d", seconds % 60);
        beDiscoverDurationView.setText(getString(R.string.allow_be_discover, String.valueOf(durationStr)));
        if (seconds <= 0) {
            disableDiscover();
        }
    }

    private void enableDiscover() {
        canDiscover = true;
        sharedPref.edit().putLong(kLastDiscoverTimes, System.currentTimeMillis()).apply();
        beDiscoverToggle.setSelected(true);
        timeReduceUtils.setSeconds(kDiscoverDuration);
        timeReduceUtils.start();
    }

    private void disableDiscover() {
        canDiscover = false;
        sharedPref.edit().putLong(kLastDiscoverTimes, 0).apply();
        beDiscoverToggle.setSelected(false);
        beDiscoverDurationView.setText(R.string.disallow_be_discover);
        timeReduceUtils.setSeconds(0);
        timeReduceUtils.pause();
    }

    private void addBluetooth(List<BluetoothDetail> list) {
        for (BluetoothDetail bluetooth : list) {
            addBluetooth(bluetooth);
        }
    }

    private void addBluetooth(BluetoothDetail bluetooth) {
        if (!bluetoothHashMap.containsKey(bluetooth.getMac())) {
            bluetoothHashMap.put(bluetooth.getMac(), bluetooth);
            bluetoothList.add(bluetooth);
        }
    }

    @Override
    public void onLeScanBegan(boolean success) {
        if (success) {
            loadingButton.setVisibility(View.GONE);
            loadingBar.setVisibility(View.VISIBLE);
            bluetoothList.clear();
            addBluetooth(BluetoothController.instance().getBondedDevices());
        } else {

            ToastUtils.showToast("扫描失败");
        }
    }

    @Override
    public void onLeScan(BluetoothDetail bluetoothDetail) {
        addBluetooth(bluetoothDetail);
        adapter.notifyData(bluetoothList);
    }

    @Override
    public void onLeScanFinished(List<BluetoothDetail> bluetoothDetails) {
        loadingButton.setVisibility(View.VISIBLE);
        loadingBar.setVisibility(View.GONE);
        bluetoothList.clear();
        addBluetooth(BluetoothController.instance().getBondedDevices());
        addBluetooth(bluetoothDetails);
        adapter.notifyData(bluetoothList);
    }

    private class BluetoothResultsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        List<BluetoothDetail> bluetoothDetails;

        BluetoothResultsAdapter() {
        }

        void notifyData(List<BluetoothDetail> bluetoothDetails) {
            this.bluetoothDetails = bluetoothDetails;
            Collections.sort(this.bluetoothDetails);
            notifyDataSetChanged();
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == 0) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bluetooth_result, parent, false);
                return new BluetoothHolder(view);
            } else {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bluetooth_no_result, parent, false);
                return new BottomHolder(view);
            }

        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof BluetoothHolder) {
                ((BluetoothHolder) holder).bindData(bluetoothDetails.get(position));
            }
        }

        @Override
        public int getItemViewType(int position) {
            if (position == getItemCount() - 1) {
                return 1;
            }
            return 0;
        }

        @Override
        public int getItemCount() {
            return bluetoothDetails == null ? 1 : bluetoothDetails.size() + 1;
        }
    }

    private class BluetoothHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView blNameView;
        TextView blStateView;
        BluetoothDetail bluetoothDetail;

        BluetoothHolder(View itemView) {
            super(itemView);
            blNameView = (TextView) itemView.findViewById(R.id.tv_bluetooth_name);
            blStateView = (TextView) itemView.findViewById(R.id.tv_bluetooth_state);
            itemView.setOnClickListener(this);
        }

        void bindData(BluetoothDetail bluetoothDetail) {
            this.bluetoothDetail = bluetoothDetail;
            blNameView.setText(bluetoothDetail.getDeviceName());
            blNameView.setSelected(bluetoothDetail.isConnected());
            blStateView.setText((bluetoothDetail.isConnected() ? "已连接" : bluetoothDetail.hasMatched() ? "已配对" : "可用"));
        }

        @Override
        public void onClick(View v) {
            ActivityBluetoothDetail.openForResult(ActivityBluetooth.this, bluetoothDetail, kRequestCodeBluetoothDetail);
        }
    }

    private class BottomHolder extends RecyclerView.ViewHolder {

        BottomHolder(View itemView) {
            super(itemView);
            TextView textView = (TextView) itemView;
            textView.setText(Html.fromHtml(getString(R.string.bluetooth_could_not_find_target_devices)));
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityBase.open(ActivityBluetooth.this, ActivityBluetoothHelper.class);
                }
            });
        }
    }
}
