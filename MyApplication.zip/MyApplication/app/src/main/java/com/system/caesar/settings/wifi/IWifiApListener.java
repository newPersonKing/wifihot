package com.system.caesar.settings.wifi;

import java.util.List;

/**
 * Created by huison on 2018/6/3.
 */

public interface IWifiApListener {

    void onScanWifiApClients(List<WifiApClient> wifiApClients);
}
