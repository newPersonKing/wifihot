package com.system.caesar.utils;

import android.text.TextUtils;
import android.widget.Toast;

import com.system.caesar.business.CaesarApplication;

/**
 * Created by huison on 2018/6/2.
 */

public class ToastUtils {

    public static void showToast(int resId) {
        showToast(CaesarApplication.context().getString(resId));
    }

    public static void showToast(String toast) {
        showToast(toast, Toast.LENGTH_SHORT);
    }

    public static void showToast(String toast, int duration) {
        if (TextUtils.isEmpty(toast)) {
            return;
        }
        Toast.makeText(CaesarApplication.context(), toast, duration).show();
    }
}
