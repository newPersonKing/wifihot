package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.business.ui.TimePicker;
import com.system.caesar.settings.SettingsController;
import com.system.caesar.utils.HandlerUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityTime extends ActivityBase implements View.OnClickListener {

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年MM月dd日");
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

    private ImageButton timeZoneAutoToggle;
    private TextView dateTextView;
    private TextView timeTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        setTitle(R.string.time);

        timeZoneAutoToggle = (ImageButton) findViewById(R.id.ib_time_zone_auto_toggle);
        timeZoneAutoToggle.setOnClickListener(this);

        findViewById(R.id.fl_date).setOnClickListener(this);
        findViewById(R.id.fl_time).setOnClickListener(this);
        findViewById(R.id.fl_double_clock).setOnClickListener(this);

        dateTextView = (TextView) findViewById(R.id.tv_date);
        timeTextView = (TextView) findViewById(R.id.tv_time);
        updateTime();
    }

    private Runnable updateTimeTask = new Runnable() {
        @Override
        public void run() {
            updateTime();
            HandlerUtils.runOnUIThreadDelay(updateTimeTask, 5000);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        timeZoneAutoToggle.setSelected(SettingsController.isAutoModifyTimeZone(this));
        updateTime();
    }

    @Override
    protected void onPause() {
        super.onPause();
        HandlerUtils.removeRunnable(updateTimeTask);
    }

    private void updateTime() {
        long time = System.currentTimeMillis();
        dateTextView.setText(dateFormat.format(new Date(time)));
        timeTextView.setText(timeFormat.format(new Date(time)));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_time_zone_auto_toggle:
                if (SettingsController.isAutoModifyTimeZone(this)) {
                    boolean success = SettingsController.setAutoModifyTimeZone(this, false);
                    if (success) {
                        timeZoneAutoToggle.setSelected(false);
                    }
                } else {
                    boolean success = SettingsController.setAutoModifyTimeZone(this, true);
                    if (success) {
                        timeZoneAutoToggle.setSelected(true);
                    }
                }
                break;
            case R.id.fl_date:
                ActivityTimeModify.open(this, TimePicker.kTimeTypeDate);
                break;
            case R.id.fl_time:
                ActivityTimeModify.open(this, TimePicker.kTimeTypeTime);
                break;
            case R.id.fl_double_clock:
                ActivityBase.open(this, ActivityTimeDoubleClock.class);
                break;
            default:
                break;
        }
    }
}
