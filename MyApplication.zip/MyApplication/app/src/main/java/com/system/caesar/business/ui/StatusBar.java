package com.system.caesar.business.ui;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.telephony.SignalStrength;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.NetWorkUtils;
import com.system.caesar.settings.SettingsController;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.settings.wifi.WifiDetail;
import com.system.caesar.utils.DensityUtils;
import com.system.caesar.utils.HandlerUtils;
import com.system.caesar.utils.PermissionUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by huison on 2018/7/5.
 */

public class StatusBar extends RelativeLayout {

    private static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

    private View container;
    private TextView operatorView;
    private TextView networkTypeView;
    private ImageView wifiView;
    private ImageView signalView;
    private ImageView batteryLevelView;
    private ImageView batteryChargeFlag;
    private TextView timeView;

    public StatusBar(Context context) {
        this(context, null);
    }

    public StatusBar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StatusBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        container = LayoutInflater.from(context).inflate(R.layout.layout_status_bar, null);
        addView(container, new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, (int) context.getResources().getDimension(R.dimen.statusBarHeight)));

        operatorView = (TextView) container.findViewById(R.id.status_tv_operator);
        networkTypeView = (TextView) container.findViewById(R.id.status_tv_network_type);
        wifiView = (ImageView) container.findViewById(R.id.status_iv_wifi);
        signalView = (ImageView) container.findViewById(R.id.status_iv_signal);
        batteryLevelView = (ImageView) container.findViewById(R.id.status_iv_battery_level);
        batteryChargeFlag = (ImageView) container.findViewById(R.id.status_iv_battery_charge);
        timeView = (TextView) container.findViewById(R.id.status_tv_time);
    }

    public void onResume() {
        if (PermissionUtils.checkPermission(getContext(), Manifest.permission.READ_PHONE_STATE)) {
            showOperatorAndNetworkType(false);
        } else {
            operatorView.setVisibility(GONE);
        }
        showWifiStatus(null);

        SettingsController.setOnBatteryChangedListener(getContext(), new SettingsController.OnBatteryChangedListener() {
            @Override
            public void onBatteryChanged(int capacity) {
                int width = (int) (capacity * 1.0f / 100 * DensityUtils.dp2px(15));
                ViewGroup.LayoutParams layoutParams = batteryLevelView.getLayoutParams();
                layoutParams.width = width;
                batteryLevelView.setLayoutParams(layoutParams);
            }
        });

        updateTime();

        getContext().registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    public void onPause() {
        HandlerUtils.removeRunnable(updateTimeTask);
        getContext().unregisterReceiver(batteryReceiver);
    }

    public void showOperatorAndNetworkType(boolean needDelayQueryNetworkType) {
        String operator = SettingsController.getOperator(getContext());
        operatorView.setText(operator);
        operatorView.setVisibility(VISIBLE);

        if (!operator.equals("无sim卡")) {
            signalView.setVisibility(VISIBLE);
            SettingsController.querySignalStrength(getContext(), new SettingsController.OnSignalStrengthListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onReadSignalStrength(SignalStrength signalStrength) {
                    int level = signalStrength.getLevel();
                    if (level >= 4) {
                        signalView.setBackgroundResource(R.mipmap.top_xh1);
                    } else if (level == 3) {
                        signalView.setBackgroundResource(R.mipmap.top_xh2);
                    } else if (level == 2) {
                        signalView.setBackgroundResource(R.mipmap.top_xh3);
                    } else if (level <= 1) {
                        signalView.setBackgroundResource(R.mipmap.top_xh4);
                    }
                }
            });
            if (needDelayQueryNetworkType) {
                HandlerUtils.runOnUIThreadDelay(new Runnable() {
                    @Override
                    public void run() {
                        updateNetworkType();
                    }
                }, 3000);
            } else {
                updateNetworkType();
            }
        } else {
            signalView.setVisibility(GONE);
            networkTypeView.setVisibility(GONE);
        }
    }

    private void updateNetworkType() {
        int networkType = NetWorkUtils.getNetWorkStatus(getContext());
        if (networkType == NetWorkUtils.NETWORK_CLASS_2_G
                || networkType == NetWorkUtils.NETWORK_CLASS_3_G
                || networkType == NetWorkUtils.NETWORK_CLASS_4_G) {
            networkTypeView.setText(networkType + "G");
            networkTypeView.setVisibility(VISIBLE);
        } else {
            networkTypeView.setVisibility(GONE);
        }
    }

    public void showWifiStatus(List<WifiDetail> wifiDetails) {
        boolean isWifiOpen = WifiController.instance().isWifiOpen();
        WifiInfo wifiInfo = WifiController.instance().getConnectionWifiInfo();
        if (isWifiOpen
                && (wifiInfo != null && wifiInfo.getSupplicantState() == SupplicantState.COMPLETED && !TextUtils.isEmpty(wifiInfo.getSSID()))) {
            wifiView.setVisibility(VISIBLE);

            if (wifiDetails != null) {
                for (WifiDetail wifiDetail : wifiDetails) {
                    if (wifiDetail.getWifiMac().equals(wifiInfo.getMacAddress())) {
                        int strength = wifiDetail.getStrength();
                        if (strength == WifiDetail.kStrengthFull) {
                            wifiView.setImageResource(R.mipmap.top_wifi1);
                        } else if (strength == WifiDetail.kStrengthThreePiece) {
                            wifiView.setImageResource(R.mipmap.top_wifi2);
                        } else if (strength == WifiDetail.kStrengthTwoPiece) {
                            wifiView.setImageResource(R.mipmap.top_wifi3);
                        } else {
                            wifiView.setImageResource(R.mipmap.top_wifi4);
                        }
                        break;
                    }
                }
            }
        } else {
            wifiView.setVisibility(GONE);
        }
    }

    private Runnable updateTimeTask = new Runnable() {
        @Override
        public void run() {
            updateTime();
        }
    };

    private void updateTime() {
        long time = System.currentTimeMillis();
        timeView.setText(timeFormat.format(new Date(time)));
        HandlerUtils.runOnUIThreadDelay(updateTimeTask, 5000);
    }

    private BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                int status = intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_UNKNOWN);
                if (status == BatteryManager.BATTERY_STATUS_CHARGING) {
                    batteryChargeFlag.setVisibility(VISIBLE);
                } else {
                    batteryChargeFlag.setVisibility(GONE);
                }
            }
        }
    };
}
