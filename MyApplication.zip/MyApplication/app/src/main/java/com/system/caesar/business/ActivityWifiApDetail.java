package com.system.caesar.business;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.WifiApServer;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.utils.ToastUtils;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityWifiApDetail extends ActivityBase {

    @Override
    protected boolean hasBackView() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_ap_detail);
        setTitle(R.string.wifi_ap_configuration);

        final EditText ssidEditText = (EditText) findViewById(R.id.et_wifi_ap_ssid_edit);
        final EditText passwordEditText = (EditText) findViewById(R.id.et_wifi_ap_password_edit);

        WifiApServer wifiApServer = WifiController.instance().getWifiApConfiguration();
        ssidEditText.setText(wifiApServer.getSSID());
        ssidEditText.setSelection(wifiApServer.getSSID().length());
        passwordEditText.setText(wifiApServer.getPassword());
        passwordEditText.setSelection(wifiApServer.getPassword().length());

        findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button saveButton = (Button) findViewById(R.id.btn_sure);
        saveButton.setText(R.string.save);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SSID = ssidEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                if (TextUtils.isEmpty(SSID) || TextUtils.isEmpty(password)) {
                    showAlertDialog("网络SSID或密码不能为空", "我知道了", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    return;
                }
                if (password.length() < 8) {
                    showAlertDialog("密码至少应包含8个字符", "我知道了", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    return;
                }
                WifiApServer wifiApServer = new WifiApServer(SSID, password, WifiApServer.kCipherTypeWpa);
                boolean success = WifiController.instance().createWifiApConfiguration(wifiApServer);
                if (success) {
                    ToastUtils.showToast("热点配置成功");
                } else {
                    ToastUtils.showToast("热点配置失败");
                }
            }
        });
    }
}
