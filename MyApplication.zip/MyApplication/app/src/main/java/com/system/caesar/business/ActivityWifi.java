package com.system.caesar.business;

import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.utils.HandlerUtils;
import com.system.caesar.settings.wifi.IWifiListener;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.settings.wifi.WifiDetail;

import java.util.Collections;
import java.util.List;

/**
 * Created by huison on 2018/5/27.
 */

public class ActivityWifi extends ActivityBase implements View.OnClickListener, IWifiListener {

    private static final int kRequestCode = 100;

    private ImageButton wifiToggle;
    private ProgressBar loadingBar;
    private ImageView loadingButton;
    private WifiResultsAdapter wifiResultsAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi);
        setTitle(R.string.item_wifi);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rv_wifi_results);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        wifiResultsAdapter = new WifiResultsAdapter();
        recyclerView.setAdapter(wifiResultsAdapter);

        wifiToggle = (ImageButton) findViewById(R.id.ib_wifi_toggle);
        wifiToggle.setOnClickListener(this);
        loadingBar = (ProgressBar) findViewById(R.id.pb_loading);
        loadingButton = (ImageView) findViewById(R.id.iv_loading);
        loadingButton.setOnClickListener(this);

        WifiController.instance().addWifiListener(this);
        boolean isWifiOpen = WifiController.instance().isWifiOpen();
        wifiToggle.setSelected(isWifiOpen);
        if (isWifiOpen) {
            loadingButton.setClickable(true);
            wifiResultsAdapter.notifyData(WifiController.instance().getWifiDetails());
        } else {
            loadingButton.setClickable(false);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WifiController.instance().registerWifiReceiver(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        WifiController.instance().unregisterWifiReceiver(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        WifiController.instance().removeWifiListener(this);
        HandlerUtils.remove();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_wifi_toggle:
                if (WifiController.instance().isWifiOpen()) {
                    WifiController.instance().closeWifi();
                    HandlerUtils.remove();
                    loadingBar.setVisibility(View.GONE);
                    loadingButton.setVisibility(View.VISIBLE);
                } else {
                    WifiController.instance().openWifi();
                }
                break;
            case R.id.iv_loading:
                loadingButton.setVisibility(View.GONE);
                loadingBar.setVisibility(View.VISIBLE);
                HandlerUtils.runOnUIThreadDelay(scanWifiListTask, 1500);
                break;
        }
    }

    private Runnable scanWifiListTask = new Runnable() {
        @Override
        public void run() {
            loadingButton.setVisibility(View.VISIBLE);
            loadingBar.setVisibility(View.GONE);
            wifiResultsAdapter.notifyData(WifiController.instance().getWifiDetails());
        }
    };

    private View.OnClickListener itemClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            WifiDetail wifiDetail = (WifiDetail) v.getTag();
            ActivityWifiDetail.openForResult(ActivityWifi.this, kRequestCode, wifiDetail);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == kRequestCode && resultCode == RESULT_OK) {
            wifiResultsAdapter.notifyData(WifiController.instance().getWifiDetails());
        }
    }

    @Override
    public void onWifiStateChanged(int state) {
        loadingButton.setClickable(false);
        switch (state) {
            case WifiManager.WIFI_STATE_DISABLED:
                wifiToggle.setSelected(false);
                break;
            case WifiManager.WIFI_STATE_DISABLING:
                break;
            case WifiManager.WIFI_STATE_ENABLED:
                wifiToggle.setSelected(true);
                loadingButton.setClickable(true);
                break;
            case WifiManager.WIFI_STATE_ENABLING:
                break;
            case WifiManager.WIFI_STATE_UNKNOWN:
                break;
            default:
                break;
        }
    }

    @Override
    public void onWifiScanChanged(List<WifiDetail> wifiDetails) {
        wifiResultsAdapter.notifyData(wifiDetails);
    }

    private class WifiResultsAdapter extends RecyclerView.Adapter<WifiResultHolder> {

        List<WifiDetail> wifiDetails;

        WifiResultsAdapter() {
        }

        void notifyData(List<WifiDetail> wifiDetails) {
            this.wifiDetails = wifiDetails;
            Collections.sort(this.wifiDetails);
            notifyDataSetChanged();
        }

        @Override
        public WifiResultHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wifi_result, parent, false);
            return new WifiResultHolder(view);
        }

        @Override
        public void onBindViewHolder(WifiResultHolder holder, int position) {
            holder.bindData(wifiDetails.get(position));
        }

        @Override
        public int getItemCount() {
            return wifiDetails == null ? 0 : wifiDetails.size();
        }
    }

    private class WifiResultHolder extends RecyclerView.ViewHolder {

        View itemView;
        TextView wifiNameView;
        TextView wifiStateView;
        ImageView wifiStrengthView;
        ImageView wifiLockedView;

        WifiResultHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            wifiNameView = (TextView) itemView.findViewById(R.id.tv_wifi_name);
            wifiStateView = (TextView) itemView.findViewById(R.id.tv_wifi_state);
            wifiStrengthView = (ImageView) itemView.findViewById(R.id.iv_wifi_strength);
            wifiLockedView = (ImageView) itemView.findViewById(R.id.iv_wifi_locked);
            this.itemView.setOnClickListener(itemClickListener);
        }

        void bindData(WifiDetail wifiDetail) {
            this.itemView.setTag(wifiDetail);
            boolean isConnected = wifiDetail.getState() == WifiDetail.kStateConnected;
            wifiNameView.setText(wifiDetail.getWifiName());
            wifiNameView.setSelected(isConnected);
            wifiLockedView.setVisibility(wifiDetail.isEncrypted() ? View.VISIBLE : View.GONE);
            if (isConnected) {
                wifiStateView.setText("已连接");
            } else {
                if (wifiDetail.isEncrypted()) {
                    wifiStateView.setText("已加密");
                } else {
                    wifiStateView.setText("未加密");
                }
            }
            if (wifiDetail.getStrength() == WifiDetail.kStrengthFull) {
                wifiStrengthView.setImageResource(R.mipmap.ic_wifi_strength_1);
            } else if (wifiDetail.getStrength() == WifiDetail.kStrengthThreePiece) {
                wifiStrengthView.setImageResource(R.mipmap.ic_wifi_strength_2);
            } else {
                wifiStrengthView.setImageResource(R.mipmap.ic_wifi_strength_3);
            }
        }
    }
}
