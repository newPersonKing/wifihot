package com.system.caesar.business;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.business.ui.DialogWaiting;
import com.system.caesar.business.ui.StatusBar;
import com.system.caesar.settings.SettingsController;
import com.system.caesar.settings.wifi.IWifiListener;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.settings.wifi.WifiDetail;

import java.util.List;

/**
 * Created by huison on 2018/6/13.
 */

public class ActivityBase extends FragmentActivity {

    public static void open(Context context, Class clazz) {
        Intent intent = new Intent(context, clazz);
        context.startActivity(intent);
    }

    private FrameLayout rootView;
    private ImageButton backView;
    private TextView titleView;
    private StatusBar statusBar;

    private DialogWaiting dialogWaiting;

    protected boolean hasNavigationBar() {
        return true;
    }

    protected boolean hasBackView() {
        return true;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        rootView = (FrameLayout) findViewById(android.R.id.content);
        LayoutInflater inflater = LayoutInflater.from(this);

        statusBar = (StatusBar) inflater.inflate(R.layout.view_status_bar, null);
        rootView.addView(statusBar);

        View toolBar = inflater.inflate(R.layout.layout_action_bar, null);
        toolBar.setBackgroundColor(getResources().getColor(R.color.action_bar));
        FrameLayout.LayoutParams toolbarLp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, (int) getResources().getDimension(R.dimen.toolbarHeight));
        toolbarLp.setMargins(0, (int) getResources().getDimension(R.dimen.statusBarHeight), 0, 0);
        if (hasNavigationBar()) {
            rootView.addView(toolBar, toolbarLp);
        }
        backView = (ImageButton) toolBar.findViewById(R.id.ib_back);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (!hasBackView()) {
            backView.setVisibility(View.GONE);
        }
        titleView = (TextView) toolBar.findViewById(R.id.tv_title);

        View contentView = inflater.inflate(layoutResID, null);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        if (hasNavigationBar()) {
            params.setMargins(0, (int) getResources().getDimension(R.dimen.toolbarHeight) + (int) getResources().getDimension(R.dimen.statusBarHeight), 0, 0);
        } else {
            params.setMargins(0, (int) getResources().getDimension(R.dimen.statusBarHeight), 0, 0);
        }
        rootView.addView(contentView, params);
    }

    @Override
    public void setTitle(int titleId) {
        setTitle(getString(titleId));
    }

    @Override
    public void setTitle(CharSequence title) {
        titleView.setText(title);
    }

    @Override
    protected void onResume() {
        super.onResume();
        statusBar.onResume();

        WifiController.instance().addWifiListener(wifiListener);
    }

    private IWifiListener wifiListener = new IWifiListener() {
        @Override
        public void onWifiStateChanged(int state) {
            statusBar.showOperatorAndNetworkType(true);
            statusBar.showWifiStatus(null);
        }

        @Override
        public void onWifiScanChanged(List<WifiDetail> wifiDetails) {
            statusBar.showWifiStatus(wifiDetails);
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        statusBar.onPause();
        WifiController.instance().removeWifiListener(wifiListener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SettingsController.release();
    }

    public void showLoading() {
        if (dialogWaiting == null) {
            dialogWaiting = new DialogWaiting(this);
            dialogWaiting.setCanceledOnTouchOutside(false);
            dialogWaiting.setCancelable(true);
        }
        if (!dialogWaiting.isShowing()) {
            dialogWaiting.show();
        }
    }

    public void dismissLoading() {
        if (dialogWaiting != null && dialogWaiting.isShowing()) {
            dialogWaiting.dismiss();
        }
    }

    public void showAlertDialog(String title, String positionButtonText, DialogInterface.OnClickListener listener) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setPositiveButton(positionButtonText, listener)
                .create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && permissions.length > 0) {
            for (int i = 0, len = permissions.length; i < len; i++) {
                String permission = permissions[i];
                int grantResult = PackageManager.PERMISSION_DENIED;
                if (i < grantResults.length) {
                    grantResult = grantResults[i];
                }
                if (permission.equals(Manifest.permission.READ_PHONE_STATE) && grantResult == PackageManager.PERMISSION_GRANTED) {
                    statusBar.showOperatorAndNetworkType(false);
                }
                if (permission.equals(Manifest.permission.ACCESS_COARSE_LOCATION) && grantResult == PackageManager.PERMISSION_GRANTED) {
                    statusBar.showWifiStatus(null);
                }
            }
        }
    }
}
