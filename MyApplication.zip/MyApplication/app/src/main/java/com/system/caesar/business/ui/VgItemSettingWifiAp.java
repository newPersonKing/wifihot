package com.system.caesar.business.ui;

import android.content.Context;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.WifiController;

/**
 * Created by huison on 2018/6/14.
 */

public class VgItemSettingWifiAp extends VgItemSettingCommon {

    public VgItemSettingWifiAp(@NonNull Context context) {
        this(context, null);
    }

    public VgItemSettingWifiAp(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VgItemSettingWifiAp(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        stateView.setText(R.string.close);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    public void refreshWifiApState() {
        if (WifiController.instance().isWifiApOpen()) {
            stateView.setText(R.string.opened);
        } else {
            stateView.setText(R.string.close);
        }
    }
}
