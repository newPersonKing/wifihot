package com.system.caesar.business;

import android.media.AudioManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.SettingsController;
import com.system.caesar.business.ui.SettingsSeekBar;

/**
 * Created by huison on 2018/6/14.
 */

public class ActivityVolume extends ActivityBase implements SettingsSeekBar.OnSeekBarChangedListener {

    @Override
    protected boolean hasNavigationBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice);

        TextView titleView = (TextView) findViewById(R.id.tv_title);
        titleView.setText(getString(R.string.item_voice));
        findViewById(R.id.ib_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        SettingsSeekBar ringVolumeSeekBar = (SettingsSeekBar) findViewById(R.id.sb_ring_volume);
        final int maxRingVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_RING);
        final int ringVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_RING);
        ringVolumeSeekBar.setMaxProgress(maxRingVolume);
        ringVolumeSeekBar.setProgress(ringVolume);
        ringVolumeSeekBar.setOnSeekBarChangedListener(this);

        SettingsSeekBar mediaVolumeSeekBar = (SettingsSeekBar) findViewById(R.id.sb_media_volume);
        final int maxMediaVolume = SettingsController.getStreamMaxVolume(this, AudioManager.STREAM_MUSIC);
        final int mediaVolume = SettingsController.getStreamVolume(this, AudioManager.STREAM_MUSIC);
        mediaVolumeSeekBar.setMaxProgress(maxMediaVolume);
        mediaVolumeSeekBar.setProgress(mediaVolume);
        mediaVolumeSeekBar.setOnSeekBarChangedListener(this);
    }

    @Override
    public void onProgressChanged(View view, int progress) {
        if (view.getId() == R.id.sb_ring_volume) {
            SettingsController.setStreamVolume(ActivityVolume.this, AudioManager.STREAM_RING, progress, false);
        } else if (view.getId() == R.id.sb_media_volume) {
            SettingsController.setStreamVolume(ActivityVolume.this, AudioManager.STREAM_MUSIC, progress, false);
        }
    }
}
