package com.system.caesar.business;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.os.Bundle;
import android.view.View;

import com.system.caesar.R;
import com.system.caesar.business.ui.ItemData;
import com.system.caesar.business.ui.VgItemSettingAirplane;
import com.system.caesar.business.ui.VgItemSettingBluetooth;
import com.system.caesar.business.ui.VgItemSettingCommon;
import com.system.caesar.business.ui.VgItemSettingMobileNet;
import com.system.caesar.business.ui.VgItemSettingWifi;
import com.system.caesar.business.ui.VgItemSettingWifiAp;
import com.system.caesar.settings.wifi.WifiController;
import com.system.caesar.utils.PermissionUtils;

public class ActivityMain extends ActivityBase implements View.OnClickListener {

    private static final int kRequestCodeForOpenWifi = 100;
    private static final int kRequestCodeForOpenWifiAp = 101;
    private static final int kRequestCodeForOpenBluetooth = 102;
    private static final int kRequestCodeForOpenSettings = 103;

    private VgItemSettingAirplane itemAirplane;
    private VgItemSettingMobileNet itemMobileNet;
    private VgItemSettingWifi itemWifi;
    private VgItemSettingBluetooth itemBluetooth;
    private VgItemSettingWifiAp itemWifiAp;
    private VgItemSettingCommon itemBrightness;
    private VgItemSettingCommon itemVoice;
    private VgItemSettingCommon itemTime;
    private VgItemSettingCommon itemLanguage;
    private VgItemSettingCommon itemSystemUpdate;
    private VgItemSettingCommon itemReset;
    private VgItemSettingCommon itemDeviceInfo;

    @Override
    protected boolean hasBackView() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(R.string.main_title);

        itemAirplane = (VgItemSettingAirplane) findViewById(R.id.vg_item_airplane);
        itemAirplane.setData(new ItemData(0, R.string.item_airplane));
        itemAirplane.setToggleOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PermissionUtils.checkAndRequestPhoneStatePermission(ActivityMain.this, kRequestCodeForOpenSettings)) {
                    boolean isAirplaneModeOn = WifiController.instance().isAirplaneModeOn(ActivityMain.this);
                    WifiController.instance().setAirplaneMode(ActivityMain.this, !isAirplaneModeOn);
                }
            }
        });

        itemMobileNet = (VgItemSettingMobileNet) findViewById(R.id.vg_item_mobile_net);
        itemMobileNet.setData(new ItemData(0, R.string.item_mobile_net));
        itemMobileNet.setToggleOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PermissionUtils.checkAndRequestPhoneStatePermission(ActivityMain.this, kRequestCodeForOpenSettings)) {
                    boolean isMobileNetOn = WifiController.instance().isMobileNetOpen(ActivityMain.this);
                    WifiController.instance().setMobileNetMode(ActivityMain.this, !isMobileNetOn);
                }
            }
        });

        itemWifi = (VgItemSettingWifi) findViewById(R.id.vg_item_wifi);
        itemWifi.setData(new ItemData(R.mipmap.sz_wlan, R.string.item_wifi));
        itemWifi.setOnClickListener(this);

        itemBluetooth = (VgItemSettingBluetooth) findViewById(R.id.vg_item_bluetooth);
        itemBluetooth.setData(new ItemData(R.mipmap.sz_blue, R.string.item_bluetooth));
        itemBluetooth.setOnClickListener(this);

        itemWifiAp = (VgItemSettingWifiAp) findViewById(R.id.vg_item_wifi_ap);
        itemWifiAp.setData(new ItemData(R.mipmap.sz_rdfx, R.string.item_wifi_ap));
        itemWifiAp.setOnClickListener(this);

        itemBrightness = (VgItemSettingCommon) findViewById(R.id.vg_item_brightness);
        itemBrightness.setData(new ItemData(R.mipmap.sz_ld, R.string.item_brightness));
        itemBrightness.setOnClickListener(this);

        itemVoice = (VgItemSettingCommon) findViewById(R.id.vg_item_voice);
        itemVoice.setData(new ItemData(R.mipmap.sz_sy, R.string.item_voice));
        itemVoice.setOnClickListener(this);

        itemTime = (VgItemSettingCommon) findViewById(R.id.vg_item_time);
        itemTime.setData(new ItemData(R.mipmap.sz_time, R.string.item_time));
        itemTime.setOnClickListener(this);

        itemLanguage = (VgItemSettingCommon) findViewById(R.id.vg_item_language);
        itemLanguage.setData(new ItemData(R.mipmap.sz_yy, R.string.item_language));
        itemLanguage.setOnClickListener(this);

        itemSystemUpdate = (VgItemSettingCommon) findViewById(R.id.vg_item_system_update);
        itemSystemUpdate.setData(new ItemData(R.mipmap.sz_xtgx, R.string.item_system_update));
        itemSystemUpdate.setOnClickListener(this);

        itemReset = (VgItemSettingCommon) findViewById(R.id.vg_item_reset);
        itemReset.setData(new ItemData(R.mipmap.sz_hf, R.string.item_reset));
        itemReset.setOnClickListener(this);

        itemDeviceInfo = (VgItemSettingCommon) findViewById(R.id.vg_item_device_info);
        itemDeviceInfo.setData(new ItemData(R.mipmap.sz_info, R.string.item_device_info));
        itemDeviceInfo.setOnClickListener(this);

        checkPermission();
    }

    private void checkPermission() {
        PermissionUtils.checkAndRequestPermission(this, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.vg_item_wifi:
                if (PermissionUtils.checkAndRequestLocationPermission(this, kRequestCodeForOpenWifi)) {
                    ActivityBase.open(this, ActivityWifi.class);
                }
                break;
            case R.id.vg_item_wifi_ap:
                if (PermissionUtils.checkAndRequestLocationPermission(this, kRequestCodeForOpenWifiAp)) {
                    ActivityBase.open(this, ActivityWifiAp.class);
                }
                break;
            case R.id.vg_item_bluetooth:
                if (PermissionUtils.checkAndRequestLocationPermission(this, kRequestCodeForOpenBluetooth)) {
                    ActivityBase.open(this, ActivityBluetooth.class);
                }
                break;
            case R.id.vg_item_brightness:
                if (PermissionUtils.checkAndRequestPhoneStatePermission(this, kRequestCodeForOpenSettings)) {
                    ActivityBase.open(this, ActivityBrightness.class);
                }
                break;
            case R.id.vg_item_voice:
                if (PermissionUtils.checkAndRequestPhoneStatePermission(this, kRequestCodeForOpenSettings)) {
                    ActivityBase.open(this, ActivityVolume.class);
                }
                break;
            case R.id.vg_item_time:
                ActivityBase.open(this, ActivityTime.class);
                break;
            case R.id.vg_item_language:
                ActivityBase.open(this, ActivityLanguage.class);
                break;
            case R.id.vg_item_system_update:
                ActivityBase.open(this, ActivitySystemUpdate.class);
                break;
            case R.id.vg_item_reset:
                ActivityBase.open(this, ActivityReset.class);
                break;
            case R.id.vg_item_device_info:
                ActivityBase.open(this, ActivityDeviceInfo.class);
                break;
            default:
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case kRequestCodeForOpenWifi:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            ActivityBase.open(this, ActivityWifi.class);
                        }
                    }
                }
                break;
            case kRequestCodeForOpenWifiAp:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            ActivityBase.open(this, ActivityWifiAp.class);
                        }
                    }
                }
                break;
            case kRequestCodeForOpenBluetooth:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            ActivityBase.open(this, ActivityBluetooth.class);
                        }
                    }
                }
                break;
            case kRequestCodeForOpenSettings:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        itemAirplane.refreshAirplaneState();
        itemWifi.refreshWifiState();
        itemMobileNet.refreshMobileNetState();
        itemWifiAp.refreshWifiApState();
        itemBluetooth.refreshBluetoothState();
    }
}
