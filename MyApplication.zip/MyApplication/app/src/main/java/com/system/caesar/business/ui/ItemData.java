package com.system.caesar.business.ui;

/**
 * Created by huison on 2018/6/14.
 */

public class ItemData {

    public int iconResId;
    public int titleResId;

    public ItemData(int iconResId, int titleResId) {
        this.iconResId = iconResId;
        this.titleResId = titleResId;
    }
}
