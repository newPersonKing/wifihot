package com.system.caesar.business;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.system.caesar.R;
import com.system.caesar.settings.bluetooth.BluetoothController;
import com.system.caesar.settings.bluetooth.BluetoothDetail;
import com.system.caesar.settings.bluetooth.IBluetoothConnectListener;
import com.system.caesar.utils.ToastUtils;

/**
 * Created by huison on 2018/6/17.
 */

public class ActivityBluetoothDetail extends ActivityBase implements View.OnClickListener {

    public static void openForResult(ActivityBase activity, BluetoothDetail bluetoothDetail, int requestCode) {
        isOwnDevice = false;
        Intent intent = new Intent(activity, ActivityBluetoothDetail.class);
        intent.putExtra("bluetooth_detail", bluetoothDetail);
        activity.startActivityForResult(intent, requestCode);
    }

    public static void openForResult(ActivityBase activity, int requestCode) {
        isOwnDevice = true;
        Intent intent = new Intent(activity, ActivityBluetoothDetail.class);
        activity.startActivityForResult(intent, requestCode);
    }

    private static boolean isOwnDevice = true;

    private EditText bluetoothNameEditText;
    private Button sureButton;

    private BluetoothDetail bluetoothDetail;

    @Override
    protected boolean hasBackView() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_detail);

        Button cancelButton = (Button) findViewById(R.id.btn_cancel);
        sureButton = (Button) findViewById(R.id.btn_sure);
        cancelButton.setOnClickListener(this);
        sureButton.setOnClickListener(this);

        if (isOwnDevice) {
            setTitle(R.string.bluetooth_configuration);
            sureButton.setText(R.string.save);
            LinearLayout bluetoothNameEditLayout = (LinearLayout) findViewById(R.id.ll_bluetooth_name_edit);
            bluetoothNameEditLayout.setVisibility(View.VISIBLE);
            bluetoothNameEditText = (EditText) findViewById(R.id.et_bluetooth_name);
            String name = BluetoothController.instance().getOwnBluetoothName();
            bluetoothNameEditText.setText(name);
            bluetoothNameEditText.setSelection(name.length());
        } else {
            bluetoothDetail = getIntent().getParcelableExtra("bluetooth_detail");
            setTitle(bluetoothDetail.getDeviceName());
            sureButton.setText(R.string.connect);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_cancel) {
            finish();
        } else if (v.getId() == R.id.btn_sure) {
            if (isOwnDevice) {
                String name = bluetoothNameEditText.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    showAlertDialog("请输入设备名称", "我知道了", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                } else {
                    boolean success = BluetoothController.instance().setOwnBluetoothName(name);
                    if (success) {
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        ToastUtils.showToast("设备名称保存失败");
                    }
                }
            } else {
                if (!BluetoothController.instance().isConnected(bluetoothDetail)) {
                    showLoading();
                    BluetoothController.instance().connect(bluetoothDetail, new IBluetoothConnectListener() {
                        @Override
                        public void OnConnectionStart() {

                        }

                        @Override
                        public void OnConnectionSuccess() {
                            dismissLoading();
                            ToastUtils.showToast("连接成功");
                            sureButton.setText(R.string.connected);
                            bluetoothDetail.setConnected(true);
                        }

                        @Override
                        public void OnConnectionFailed(String error) {
                            dismissLoading();
                            ToastUtils.showToast("连接失败，" + error);
                        }
                    });
                } else {
                    // TODO disconnect
                }
            }
        }
    }
}
