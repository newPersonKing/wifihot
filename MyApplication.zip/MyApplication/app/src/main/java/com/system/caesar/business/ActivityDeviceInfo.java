package com.system.caesar.business;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.system.caesar.R;
import com.system.caesar.settings.SettingsController;

/**
 * Created by huison on 2018/6/18.
 */

public class ActivityDeviceInfo extends ActivityBase implements View.OnClickListener {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_info);
        setTitle(R.string.device_info);

        findViewById(R.id.fl_device_qr_code).setOnClickListener(this);

        ((TextView) findViewById(R.id.tv_device_model)).setText(Build.MODEL);

        ((TextView) findViewById(R.id.tv_system_version)).setText(Build.VERSION.RELEASE);

        long memorySize = SettingsController.getTotalMemorySize(this);
        ((TextView) findViewById(R.id.tv_raw_info)).setText(formatMemory(memorySize));

        long availableInternalMemorySize = SettingsController.getAvailableInternalMemorySize();
        ((TextView) findViewById(R.id.tv_usable_storage)).setText(getString(R.string.usable_storage, formatMemory(availableInternalMemorySize)));

        long totalInternalMemorySize = SettingsController.getTotalInternalMemorySize();
        ((TextView) findViewById(R.id.tv_total_storage)).setText(getString(R.string.total_storage, formatMemory(totalInternalMemorySize)));
    }

    private static String formatMemory(long memory) {
        float memoryM = memory * 1.0f / 1024 / 1024;
        if (memoryM >= 1024) {
            float memoryG = memoryM * 1.0f / 1024;
            return String.format("%.1f", memoryG) + "G";
        } else {
            return String.format("%.1f", memoryM) + "M";
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fl_device_qr_code:
                ActivityBase.open(this, ActivityDeviceQrCode.class);
                break;
        }
    }
}
