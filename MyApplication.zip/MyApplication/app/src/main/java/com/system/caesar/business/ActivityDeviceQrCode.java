package com.system.caesar.business;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/18.
 */

public class ActivityDeviceQrCode extends ActivityBase {

    @Override
    protected boolean hasNavigationBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_qr_code);

        TextView titleView = (TextView) findViewById(R.id.tv_title);
        titleView.setText(getString(R.string.device_qr_code));
        findViewById(R.id.ib_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
