package com.system.caesar.business.ui;

import android.content.Context;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.system.caesar.R;

/**
 * Created by huison on 2018/6/14.
 */

public class VgItemSettingCommon extends FrameLayout {

    protected View container;
    protected ImageView iconView;
    protected TextView titleView;
    protected TextView stateView;
    protected ImageView enterView;

    public VgItemSettingCommon(@NonNull Context context) {
        this(context, null);
    }

    public VgItemSettingCommon(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VgItemSettingCommon(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        container = LayoutInflater.from(context).inflate(R.layout.layout_item_setting, null);
        addView(container);

        iconView = (ImageView) container.findViewById(R.id.iv_item_icon);
        titleView = (TextView) container.findViewById(R.id.tv_item_title);
        stateView = (TextView) container.findViewById(R.id.tv_item_state);
        enterView = (ImageView) container.findViewById(R.id.iv_enter);
    }

    public void setData(ItemData itemData) {
        if (itemData != null) {
            iconView.setImageResource(itemData.iconResId);
            titleView.setText(itemData.titleResId);
        }
    }
}