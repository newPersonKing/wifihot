package com.system.caesar.business.ui;

import android.content.Context;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;

import com.system.caesar.R;
import com.system.caesar.settings.wifi.WifiController;

/**
 * Created by huison on 2018/6/14.
 */

public class VgItemSettingWifi extends VgItemSettingCommon {

    public VgItemSettingWifi(@NonNull Context context) {
        this(context, null);
    }

    public VgItemSettingWifi(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VgItemSettingWifi(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        stateView.setText(R.string.close);
    }

    public void refreshWifiState() {
        if (WifiController.instance().isWifiOpen()) {
            WifiInfo wifiInfo = WifiController.instance().getConnectionWifiInfo();
            if (wifiInfo != null && wifiInfo.getSupplicantState() == SupplicantState.COMPLETED && !TextUtils.isEmpty(wifiInfo.getSSID())) {
                stateView.setText(wifiInfo.getSSID().replace("\"", ""));
            }
        } else {
            stateView.setText(R.string.close);
        }
    }
}
